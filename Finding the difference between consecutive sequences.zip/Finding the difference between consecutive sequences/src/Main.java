/*
    Ali Arslan
    1210505017
    2-) Bir tamsayı dizisi verildiğinde, sıralanmış biçiminde iki ardışık öğe
    arasındaki maksimum farkı döndürün. Dizi ikiden az öğe içeriyorsa, 0 değerini
    döndürün.
*/


import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner girdi = new Scanner(System.in);
        System.out.println("\n-------Dizideki İki Ardışık Elemanların Arasındaki Maksimum Farkı Bulma-------\n");
        System.out.println("Dizinizin eleman sayısını giriniz:");
        int elemanSayisi = girdi.nextInt();

        /*
        ---------------------------------------
        Dizinin elemanlarını kullanıcıdan alma
        ---------------------------------------
        */
        System.out.println("Dizinin elemanlarını giriniz:");

        int dizi[] = new int[elemanSayisi];
        int i;
        for (i = 0; i < elemanSayisi; i++){
            dizi[i]=girdi.nextInt();
        }
        /*
        --------------------------------------------
        Dizideki elemanları bubbleSort ile sıralama
        --------------------------------------------
        */


        int gecici;
        for ( i = 0; i <= dizi.length - 1; i++)
        {
            for (int j = 1; j <= dizi.length - 1; j++)
            {
                if (dizi[j - 1] > dizi[j])
                {
                    gecici = dizi[j - 1];
                    dizi[j - 1] = dizi[j];
                    dizi[j] = gecici;
                }
            }
        }

        /*
        -----------------------------------------------
        Ardışık iki elemanın farkını bulma
        -----------------------------------------------
        */



        if (dizi.length > 2){
            int enFark = 0;
            for ( i = 0; i < dizi.length - 2; i++) {
                int diff = Math.abs(dizi[i] - dizi[i + 2]);
                if (diff > enFark) {
                        enFark = diff;
                }
            }
            System.out.println("Çıktı: "+enFark);

        }
        else {
            System.out.println("Çıktı: 0");
        }


    }
}
